﻿namespace FireChat.Constants {
    public class Credentials {

        public const string SyncfusionKey = "Mzg1NjgzOEAzMjM5MmUzMDJlMzAzYjMyMzkzYkhYNmg1NmtERzZ1QXNNVkZsYkFFTHdaZUxOTXlreG9UekFtTDE2R2xvUTA9";

        public const string FirebaseAuthApiKey = "AIzaSyCIBF0Zx00CoiNv8rfXNkn2-A58isSNznY";

        public const string FirebaseProjectId = "firechat-5db0b";
    }
}
