﻿namespace FireChat.Constants {
    public class Credentials {

        public const string SyncfusionKey = "Mzc2MTEyNkAzMjM4MmUzMDJlMzBDWXlKcnVGd3JMU1U3bGd4NU1OMWFNZjRLenJsTjRMNHY4cTg3TURucmtnPQ==";

        public const string FirebaseAuthApiKey = "AIzaSyCIBF0Zx00CoiNv8rfXNkn2-A58isSNznY";
    }
}
