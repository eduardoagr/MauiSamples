﻿namespace FireChat.Constants {
    public class Credentials {

        public const string SyncfusionKey = "Mzg1MzkyNUAzMjM5MmUzMDJlMzAzYjMyMzkzYlJTOWgzKzlRbnlwSlNnWVY3SkxoMWcxWVB0Um1ucyt3SjQ5Q2xIeDVFTVk9s==";

        public const string FirebaseAuthApiKey = "AIzaSyCIBF0Zx00CoiNv8rfXNkn2-A58isSNznY";

        public const string FirebaseProjectId = "firechat-5db0b";
    }
}
