namespace FireChat.Views.PopUps;

public partial class LoadingPopUp : Popup {

    public LoadingPopUp() {
        InitializeComponent();
    }
}