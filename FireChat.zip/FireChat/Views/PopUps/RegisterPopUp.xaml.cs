
namespace FireChat.Views.PopUps;

public partial class RegisterPopUp : SfPopup {

    public RegisterPopUp() {
        InitializeComponent();
    }
}