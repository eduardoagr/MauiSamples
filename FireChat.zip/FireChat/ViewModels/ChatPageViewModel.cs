﻿namespace FireChat.ViewModels;

public partial class ChatPageViewModel : BaseViewModel {


}
