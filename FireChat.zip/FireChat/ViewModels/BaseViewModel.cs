﻿namespace FireChat.ViewModels;

public partial class BaseViewModel : ObservableObject
{
}
