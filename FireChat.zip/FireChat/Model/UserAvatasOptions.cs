﻿namespace FireChat.Model;

public class UserAvatasOptions {

    public string? Name { get; set; }

    public bool IsFirst { get; set; } // ✅ Flags the first item

}
